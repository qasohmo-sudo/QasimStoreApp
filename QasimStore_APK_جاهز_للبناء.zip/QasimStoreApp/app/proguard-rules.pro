# Qasim Store release rules.
